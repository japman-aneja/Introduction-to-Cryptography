with open("ciphertext.bin", 'rb') as f:
    ciphertext = f.read()

# create blocks of ciphertext
blocks = []
for i in range(0, len(ciphertext), 16):
    blocks.append(ciphertext[i : i + 16])

HEADER = "_Have you heard about the \{quick\} brown fox which jumps over the lazy dog?\n__The decimal number system uses the digits 0123456789!\n___The flag is: "

mapping = {}
for i in range(0, len(HEADER)):
    mapping[blocks[i]] = HEADER[i]

flag = ""

for i in range(len(HEADER), len(blocks)):
    if blocks[i] in mapping :
        flag += mapping[blocks[i]]
    else :
        flag += '?'

print(flag)