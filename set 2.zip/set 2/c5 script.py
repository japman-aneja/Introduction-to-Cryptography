from pwn import *
from Crypto.Util.Padding import pad, unpad

HOST = "0.cloud.chals.io"
PORT = 19966

# Uncomment the 'process' line below when you want to test locally, uncomment the 'remote' line below when you want to execute your exploit on the server
# target = process(["python", "./server.py"])
target = remote(HOST, PORT)

def recvuntil(msg):
    resp = target.recvuntil(msg.encode()).decode()
    print(resp)
    return resp

def sendline(msg):
    print(msg)
    target.sendline(msg.encode())

def recvline():
    resp = target.recvline().decode()
    print(resp)
    return resp

def recvall():
    resp = target.recvall().decode()
    print(resp)
    return resp


recvuntil("IV: ")
IV = bytes.fromhex(recvline())

recvuntil("Flag: ")
flag_enc = bytes.fromhex(recvline())


def validate_padding(iv_hex: str, ciphertext_hex: str) -> bool:
    recvuntil("validated:\n")
    sendline(ciphertext_hex)
    recvuntil("IV:\n")
    sendline(iv_hex)
    response = recvline()
    valid_padding = ("Valid Padding!" in response)
    return valid_padding


# ===== YOUR CODE BELOW =====
# The variable IV has the iv (as a bytes object)
# The variable flag_enc has the ciphertext (as a bytes object)
# You can call the function validate_padding(iv_hex: str, ciphertext_hex: str) -> bool which takes in the hex of the iv (str) and hex of the ciphertext (str) and returns True if the corresponding plaintext has valid padding, and return False otherwise (as dictated by the server's response)

def recover_block(previous, target):
    C1 = bytes.fromhex(previous)
    Cx = bytearray(16)
    P2 = bytearray(16)

    C_target = target  # untouched, sent to oracle

    for i in range(1,17):
        for j in range(1,i):
            Cx[16 - j] = i ^ P2[16 - j] ^ C1[16 - j]

            for k in range(256):
                Cx[16 - i] = k
                if validate_padding(Cx.hex(), target):
                    P2[16 - i] = i ^ C1[16 - i] ^ k
                    break

    return P2

blocks = []
for i in range(0,len(flag_enc.hex()), 32):
    blocks.append(flag_enc.hex()[i : i + 32])

# splitting ciphertext into 16-byte blocks
print(recover_block(IV.hex(), blocks[0]))
print(recover_block(blocks[0], blocks[1]))



# ===== YOUR CODE BELOW =====

target.close()
