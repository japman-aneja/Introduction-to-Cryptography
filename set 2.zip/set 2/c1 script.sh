#!/bin/bash

KEY=$(cat key.hex)
IV=$(cat iv.hex)

openssl enc -aes-128-cbc -d -in ciphertext.bin -K "$KEY" -iv "$IV" -out flag.txt

cat flag.txt
