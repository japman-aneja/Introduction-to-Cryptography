import hashlib

with open("ciphertext.enc", 'rb') as f:
    encrypted_flag = f.read()

for first_byte in range(128):
    key_bytes = bytes([first_byte])
    for i in range(1, len(encrypted_flag)):
        key_bytes += bytes([hashlib.sha256(bytes(key_bytes)).digest()[0] % 128])

    decrypted_flag = bytes((encrypted_flag[i] - key_bytes[i]) % 128 for i in range(len(encrypted_flag)))

    try:
        text = decrypted_flag.decode('ascii')
        if text.startswith("cs"):
            print(f"First key byte: {first_byte}, Flag: {text}")
    except UnicodeDecodeError:
        pass