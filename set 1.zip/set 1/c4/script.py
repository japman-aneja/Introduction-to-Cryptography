with open("ciphertext.enc", "rb") as f:
    cipher_bytes = f.read()
with open("keyfile", "rb") as f:
    key = list(f.read())

num = int.from_bytes(cipher_bytes, "big")
cipher_digits = []
while num > 0:
    cipher_digits.append(num % 255)
    num //= 255
cipher_digits.reverse()

plain_digits = [(ci - ki + 1) % 255 for ci, ki in zip(cipher_digits, key)]

num = 0
for d in plain_digits:
    num = num * 255 + d
plaintext = num.to_bytes((num.bit_length() + 7) // 8, "big")

print(plaintext.decode())