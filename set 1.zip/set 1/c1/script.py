# opening the ciphertext files
with open("ciphertext1.enc", "rb") as f:
    ciphertext1 = f.read()
with open("ciphertext2.enc", "rb") as f:
    ciphertext2 = f.read()
# assuming both ciphertexts are of the same length
L = len(ciphertext1)

# XOR function to compute m1 ^ m2 = c1 ^ c2
m1_xor_m2 = bytes(a ^ b for a, b in zip(ciphertext1, ciphertext2))

while(True) :
    inp = input("Enter <ciphertext_number (1 or 2)> <known_text> (or 'quit' to exit):\n> ").strip()
    
    if inp.lower() in ("quit", "exit"):
        break

    parts = inp.split(" ", 1)

    if(len(parts) < 2):
        continue
    
    which_cipher, known_text = parts

    n = len(known_text)

    if n > L:
        continue

    segment = m1_xor_m2[:n]

    other_bytes = bytes(ord(a) ^ b for a, b in zip(known_text, segment))

    try:
        other_str = other_bytes.decode('ascii')
    except UnicodeDecodeError:
        other_str = other_bytes.hex()
        print("Output has non-ASCII bytes; showing hex:")

    if which_cipher == '1':
        print(f"Known ciphertext1 bytes: '{known_text}'")
        print(f"Corresponding ciphertext2 bytes: '{other_str}'\n")
    else:
        print(f"Known ciphertext2 bytes: '{known_text}'")
        print(f"Corresponding ciphertext1 bytes: '{other_str}'\n")